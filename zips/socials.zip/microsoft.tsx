import { cn } from '@/lib/utils';

type MicrosoftProps = React.SVGAttributes<SVGElement>;

export const Microsoft = ({ className, ...props }: MicrosoftProps) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className={cn('h-5 w-5', className)}
    {...props}
  >
    <rect width="11" height="11" fill="#F25022" />
    <rect x="13" width="11" height="11" fill="#7FBA00" />
    <rect y="13" width="11" height="11" fill="#00A4EF" />
    <rect x="13" y="13" width="11" height="11" fill="#FFB900" />
  </svg>
);