'use client';

import { memo, useEffect, useState } from 'react';
import { useTheme } from 'next-themes';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

import MoonIcon from './MoonIcon';
import SunIcon from './SunIcon';
import SystemIcon from './SystemIcon';

const THEME_OPTIONS = [
  { value: 'light', label: 'Light', icon: SunIcon },
  { value: 'dark', label: 'Dark', icon: MoonIcon },
  { value: 'system', label: 'System', icon: SystemIcon },
] as const;

/**
 * Theme toggle dropdown with automatic icon switching.
 * SSR-safe with smooth transitions and smart icon detection.
 */
const ThemeToggle = memo(() => {
  const { theme, resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  const getTriggerIcon = () => {
    if (theme === 'system') {
      return resolvedTheme === 'dark' ? MoonIcon : SunIcon;
    }
    return (
      THEME_OPTIONS.find(option => option.value === theme)?.icon || SunIcon
    );
  };

  useEffect(() => {
    setMounted(true);
  }, []);

  const TriggerIcon = getTriggerIcon();

  if (!mounted) {
    return (
      <div className="flex h-[40px] w-[48px] items-center justify-center">
        <div className="h-5 w-5 animate-pulse rounded-full bg-gray-300 dark:bg-gray-600" />
      </div>
    );
  }

  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild>
        <button
          className="flex items-center gap-2 rounded-md border-none px-3 py-2 transition-colors hover:cursor-pointer hover:bg-gray-100 focus:outline-none dark:hover:bg-gray-700/50"
          aria-label="Change theme"
        >
          <TriggerIcon />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        className="min-w-[150px] rounded border border-gray-200 bg-white dark:border-gray-700 dark:bg-gray-800"
        align="end"
        sideOffset={8}
      >
        {THEME_OPTIONS.map(({ value, label, icon: Icon }) => (
          <DropdownMenuItem
            key={value}
            onClick={() => setTheme(value)}
            className={`flex cursor-pointer items-center gap-2 rounded px-3 py-2 transition-colors hover:!bg-gray-100 dark:hover:!bg-gray-700 ${
              theme === value ? 'bg-gray-50 font-bold dark:!bg-gray-700/50' : ''
            }`}
          >
            <Icon aria-hidden="true" />
            <span className="text-gray-900 dark:text-gray-100">{label}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
});

ThemeToggle.displayName = 'ThemeToggle';

export default ThemeToggle;