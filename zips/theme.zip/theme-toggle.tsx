'use client';

import { memo, useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import { useTheme } from 'next-themes';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

import { Button } from '../ui/button';

import MoonIcon from './MoonIcon';
import SunIcon from './SunIcon';
import SystemIcon from './SystemIcon';

const THEME_OPTIONS = [
  { value: 'light', label: 'Light', icon: SunIcon },
  { value: 'dark', label: 'Dark', icon: MoonIcon },
  { value: 'system', label: 'System', icon: SystemIcon },
] as const;

/**
 * Theme toggle dropdown with automatic icon switching.
 * SSR-safe with smooth transitions and smart icon detection.
 */
const ThemeToggle = memo(() => {
  const { theme, resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  const getTriggerIcon = () => {
    if (theme === 'system') {
      return resolvedTheme === 'dark' ? MoonIcon : SunIcon;
    }
    return (
      THEME_OPTIONS.find(option => option.value === theme)?.icon || SunIcon
    );
  };

  useEffect(() => {
    setMounted(true);
  }, []);

  const TriggerIcon = getTriggerIcon();

  if (!mounted) {
    return (
      <div className="flex h-9 w-9 items-center justify-center">
        <div className="bg-secondary/50 dark:bg-secondary/50 h-5 w-5 animate-pulse rounded-full" />
      </div>
    );
  }

  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          aria-label="Change theme"
          className="hover:bg-primary/20 dark:hover:bg-primary/30 transition-colors"
        >
          <TriggerIcon className="size-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        className="border-border min-w-[150px] rounded border"
        align="end"
        sideOffset={8}
      >
        {THEME_OPTIONS.map(({ value, label, icon: Icon }) => (
          <DropdownMenuItem
            key={value}
            variant="theme"
            onClick={() => setTheme(value)}
            data-theme-selected={theme === value}
            className={cn(
              'cursor-pointer px-3 py-2',
              theme === value &&
                'bg-primary/30 hover:bg-primary/30 dark:bg-primary/45 dark:hover:bg-primary/45 font-bold'
            )}
          >
            <Icon aria-hidden="true" />
            <span className="text-foreground">{label}</span>
            {theme === value && (
              <Check className="text-foreground ml-auto size-4" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
});

ThemeToggle.displayName = 'ThemeToggle';

export default ThemeToggle;