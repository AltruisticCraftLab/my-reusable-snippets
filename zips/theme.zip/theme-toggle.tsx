"use client";

import { useTheme } from "next-themes";
import { memo, useEffect, useMemo, useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import SunIcon from "./SunIcon";
import MoonIcon from "./MoonIcon";
import SystemIcon from "./SystemIcon";

/**
 * Theme options configuration
 * Add or modify theme options here
 */
const THEME_OPTIONS = [
  { value: "light", label: "Light", icon: SunIcon },
  { value: "dark", label: "Dark", icon: MoonIcon },
  { value: "system", label: "System", icon: SystemIcon },
] as const;

/**
 * ThemeToggle - Animated dropdown for switching between light/dark/system themes
 *
 * Features:
 * - SSR-safe with proper hydration handling
 * - Smooth animations and micro-interactions
 * - Full accessibility support
 * - Automatic icon switching based on current theme
 *
 * @returns Memoized theme toggle dropdown component
 */
const ThemeToggle = memo(() => {
  const { theme, resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // Determine which icon to show in the trigger button
  const TriggerIcon = useMemo(() => {
    if (theme === "system") {
      return resolvedTheme === "dark" ? MoonIcon : SunIcon;
    }
    return (
      THEME_OPTIONS.find((option) => option.value === theme)?.icon || SunIcon
    );
  }, [theme, resolvedTheme]);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Prevent hydration mismatch by showing placeholder until mounted
  if (!mounted) {
    return (
      <div className="w-[48px] h-[40px] flex items-center justify-center opacity-0 animate-pulse">
        <div className="w-5 h-5 bg-gray-300 rounded-full dark:bg-gray-600" />
      </div>
    );
  }

  return (
    <div className="animate-in fade-in-0 duration-200">
      <DropdownMenu modal={false}>
        <DropdownMenuTrigger asChild>
          <button
            className="flex items-center gap-2 px-3 py-2 border-none rounded-md hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-all duration-200 ease-in-out hover:scale-105 focus:outline-none focus:ring-2 focus:ring-gray-300 dark:focus:ring-gray-600 hover:cursor-pointer"
            aria-label="Toggle theme"
            title="Change theme"
          >
            <div className="transition-transform duration-200 ease-in-out hover:rotate-12">
              <TriggerIcon />
            </div>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          className="min-w-[150px] rounded-lg bg-white dark:bg-gray-800 border dark:border-gray-700 border-gray-200 shadow-lg animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 duration-200"
          align="end"
          sideOffset={8}
        >
          {THEME_OPTIONS.map(({ value, label, icon: Icon }) => (
            <DropdownMenuItem
              key={value}
              onClick={() => setTheme(value)}
              className={`flex items-center gap-2 px-3 py-2 rounded-md cursor-pointer hover:!bg-gray-100 dark:hover:!bg-gray-700 transition-all duration-150 ease-in-out hover:translate-x-1 ${
                theme === value
                  ? "font-bold bg-gray-50 dark:!bg-gray-700/50 scale-[1.02]"
                  : "hover:scale-[1.01]"
              }`}
            >
              <div className="transition-transform duration-150 ease-in-out">
                <Icon />
              </div>
              <span className="text-gray-900 dark:text-gray-100 transition-colors duration-150">
                {label}
              </span>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
});

ThemeToggle.displayName = "ThemeToggle";

export default ThemeToggle;
