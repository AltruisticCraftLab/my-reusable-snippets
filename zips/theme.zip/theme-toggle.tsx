//   src/components/theme/theme-toggle.tsx

"use client";

import { useTheme } from "next-themes";
import { memo, useEffect, useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import SunIcon from "./SunIcon";
import MoonIcon from "./MoonIcon";
import SystemIcon from "./SystemIcon";

const ThemeToggle = memo(() => {
  const { theme, resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  const THEME_OPTIONS = [
    { value: "light", label: "Light", icon: SunIcon },
    { value: "dark", label: "Dark", icon: MoonIcon },
    { value: "system", label: "System", icon: SystemIcon },
  ] as const;

  // Get the appropriate icon for the trigger button
  const getTriggerIcon = () => {
    if (theme === "system") {
      return resolvedTheme === "dark" ? MoonIcon : SunIcon;
    }
    return (
      THEME_OPTIONS.find((option) => option.value === theme)?.icon || SunIcon
    );
  };

  useEffect(() => {
    setMounted(true);
  }, []);

  const TriggerIcon = getTriggerIcon();

  if (!mounted) {
    return null;
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2 px-3 py-2 border-none rounded-md hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors focus:outline-none hover:cursor-pointer">
          <TriggerIcon />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        className="min-w-[150px] rounded bg-white dark:bg-gray-800 border dark:border-gray-700 border-gray-200"
        align="end"
        sideOffset={8}
      >
        {THEME_OPTIONS.map(({ value, label, icon: Icon }) => (
          <DropdownMenuItem
            key={value}
            onClick={() => setTheme(value)}
            className={`flex items-center gap-2 px-3 py-2 rounded cursor-pointer hover:!bg-gray-100 dark:hover:!bg-gray-700 transition-colors ${
              theme === value ? "font-bold bg-gray-50 dark:!bg-gray-700/50" : ""
            }`}
          >
            <Icon />
            <span className="text-gray-900 dark:text-gray-100">{label}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
});

ThemeToggle.displayName = "ThemeToggle";

export default ThemeToggle;
